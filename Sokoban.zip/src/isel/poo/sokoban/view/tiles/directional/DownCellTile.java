package isel.poo.sokoban.view.tiles.directional;

import isel.poo.sokoban.model.cells.Cell;

public final class DownCellTile extends DirectionalCellTile {

    public DownCellTile(Cell cell) { super(cell, '˅'); }

}

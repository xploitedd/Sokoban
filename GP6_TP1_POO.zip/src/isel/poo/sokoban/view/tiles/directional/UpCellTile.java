package isel.poo.sokoban.view.tiles.directional;

import isel.poo.sokoban.model.cells.Cell;

public final class UpCellTile extends DirectionalCellTile {

    public UpCellTile(Cell cell) {
        super(cell, '˄');
    }

}
